
-- Consumer Page in IOKit/hid/IOHIDUsageTables.h
KEY_TYPE = {
    HOME_BUTTON = 0x40,
    VOLUME_DOWN_BUTTON = 0xEA,
    VOLUME_UP_BUTTON = 0xE9,
    POWER_BUTTON = 0x30
}

ORIENTATION_TYPE = {
    UNKNOWN = 0,
    PORTRAIT = 1, -- Device oriented vertically, home button on the bottom
    PORTRAIT_UPSIDE_DOWN = 2, -- Device oriented vertically, home button on the top
    LANDSCAPE_LEFT = 3, -- Device oriented horizontally, home button on the right
    LANDSCAPE_RIGHT = 4 -- Device oriented horizontally, home button on the left
}

CONTROLLER_TYPE = {
    LABEL = 1,
    INPUT = 2,
    PICKER = 3,
    SWITCH = 4
}

----------------------------------------

function lockScreen()
    keyDown(KEY_TYPE.POWER_BUTTON);
    keyUp(KEY_TYPE.POWER_BUTTON);
end

function unlockScreen()
    keyDown(KEY_TYPE.POWER_BUTTON);
    keyUp(KEY_TYPE.POWER_BUTTON);

    usleep(1000000);

    local w, h = getScreenResolution();

    local x = 10;
    local gap = 120;
    touchDown(0, x, 200);
    while x < w do
        x = x + gap;
        usleep(16000);
        touchMove(0, x, 200);
    end
    touchUp(0, x, 200);
end

----------------------------------------

function getScreenResolution()
    local w, h = getScreenSize();
    local scale = getScreenScale();
    return w * scale, h * scale;
end

----------------------------------------

function intToRgb(intColor)
    local r = math.floor(intColor / (256 * 256));
    local g = math.floor((intColor - r * 256 * 256) / 256);
    local b = math.floor((intColor - r * 256 * 256 - g * 256));
    return r, g, b;
end

function rgbToInt(r, g, b)
    return r * 256 * 256 + g * 256 + b;
end

function getColor(x, y)
    local colors = getColors({{x,y}});
    if colors ~= nil and #colors > 0 then
    	return colors[1];
    end
    return -1;
end

-- color: the color to find
-- count: 0 means all, 1 means first, 2 means first and second
-- region: region
function findColor(color, count, region)
    return findColors({{color,0,0}}, count, region);
end

-------------deprecated-----------------
function homeButtonDown()
    keyDown(KEY_TYPE.HOME_BUTTON);
end

function homeButtonUp()
    keyUp(KEY_TYPE.HOME_BUTTON);
end

function rootPathOfDocuments()
    return rootDir();
end

function logging(logContent)
    return log(logContent);
end

function tap(x, y)
    touchDown(0, x, y);
    usleep(16000);
    touchUp(0, x, y);
end

-- color: the color to find
-- count: 0 means all, 1 means first, 2 means first and second
-- region: region
function findColorTap(color, count, region)
    local result = findColor(color, count, region);
    if result ~= nil then
        for i, v in pairs(result) do
            tap(v[1], v[2]);
            usleep(16000);
        end
    end
end

-- will block current process
function findColorsTap(colors, count, region)
    local locations = findColors(colors, count, region);
    for i, v in pairs(locations) do
        tap(v[1], v[2]);
        usleep(16000);
    end
end

function findImageTap(imagePath, count, fuzzy, ignoreColors, region)
    local locations = findImage(imagePath, count, fuzzy, ignoreColors, region);
    for i, v in pairs(locations) do
        tap(v[1], v[2]);
        usleep(16000);
    end
end

function keepFindingColor(color, count, region, func, interval, exit)
    local f = function()
        local locations = findColor(color, count, region);
        func(locations);
    end

    keep(f, interval, exit);
end

function keep(func, interval, exit)
    local f = function ()
        local firstLoop = true;
        while true do
            if exit then
                coroutine.yield();
            end
            if firstLoop then
                firstLoop = false;
            else
                usleep(interval);
            end
            func();
        end
    end

    local co = coroutine.create(f);
    coroutine.resume(co);
end

-- won't block current process
-- func: the action you want to run when the colors are found, it should be like: local f = function (locations) ... end
function keepFindingColors(colors, count, region, func, interval, exit)
    local f = function()
        local locations = findColors(colors, count, region);
        func(locations);
    end

    keep(f, interval, exit);
end

function keepFindingImage(imagePath, count, fuzzy, ignoreColors, region, func, interval, exit)
    local f = function()
        local locations = findImage(imagePath, count, fuzzy, ignoreColors, region);
        func(locations);
    end

    keep(f, interval, exit);
end

function keepFindingColorTap(color, count, region, interval, exit)
    local f = function()
        findColorTap(color, count, region);
    end

    keep(f, interval, exit);
end

function keepFindingColorsTap(colors, count, region, interval, exit)
    local f = function()
        findColorsTap(colors, count, region);
    end

    keep(f, interval, exit);
end

function keepFindingImageTap(imagePath, count, fuzzy, ignoreColors, region, interval, exit)
    local f = function()
        findImageTap(imagePath, count, fuzzy, ignoreColors, region);
    end

    keep(f, interval, exit);
end

function appIsActive(appIdentifier)
    return "ACTIVATED" == appState(appIdentifier);
end
----------------------------------------